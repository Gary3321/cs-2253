#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "deal_with_string.h"

char operation[17], operand1[17], operand2[27], operand3[17];
char* get_operation_bin(char *operation);
char* get_operand_bin(char *operand);

char* get_operand_bin(char *operand)
{
	if (strstr(operand,"R"))	
	{
		if (strcmp(operand, "R0")==0) return "000";
		if (strcmp(operand, "R1")==0) return "001";
		if (strcmp(operand, "R2")==0) return "010";
		if (strcmp(operand, "R3")==0) return "011";
		if (strcmp(operand, "R4")==0) return "100";
		if (strcmp(operand, "R5")==0) return "101";
		if (strcmp(operand, "R6")==0) return "110";
		if (strcmp(operand, "R7")==0) return "111";
		else return ""; //return null
	}
		else return ""; 
}
char* read_symbol_table(char* symbol)
{
	FILE *fp=fopen("symbol_table.sym","r");
	char data[1000];
	char* ptr;
	if(!fp)
    {
        printf("can't open file\n");
        return false;
    }
	while ((fgets(data,1000,fp))!=NULL)
	{
	if(strlen(data)!=1) 
	{
		ptr=strtok(data," ");
		trim_string(ptr);//remove space and enter
		if(strcmp(ptr,symbol)==0)
		{
			ptr = strtok(NULL," ");
			trim_string(ptr);
			return ptr;
		}
	}
	}
	fclose(fp);
	return "3fff";//error
}
void get_code_bin(char* operation, char* operand1, char* operand2, char* operand3, FILE *fp_w, int pc)
{
	char* op3=get_operand_bin(operand3);
	char* op2=get_operand_bin(operand2);
	char* op1=get_operand_bin(operand1);
	char* sysbol_address;
	char code[16]; //bin code
	char binary[16]; //binary
	char binary_full[16]; //binary with length of 5
	int op3_int,offset;
	//char *code_bin;
	/****************************************************************************/
	if (strcmp(operation,"SUB")==0)
	{
		memset(code,0,sizeof(code)); //clear array code
		if(strlen(op2)>1 && strlen(op3)>1) //two registers
		{
			strcat(code,"1001");
			strcat(code,op3);
			strcat(code,op3);
			strcat(code,"111111"); 
			fprintf(fp_w,"%s\n",code); //NOT
			memset(code,0,sizeof(code));
			strcat(code,"0001"); 
			strcat(code,op3);
			strcat(code,op3);
			strcat(code,"100001");  
			fprintf(fp_w,"%s\n",code); //ADD 1
			memset(code,0,sizeof(code));
			strcat(code,"0001"); 
			strcat(code,op1);
			strcat(code,op2);
			strcat(code,"000");
			strcat(code,op3);
			fprintf(fp_w,"%s\n",code); //SUB
			memset(code,0,sizeof(code));//clear code
			
		}
	}
	else if (strcmp(operation,"SHL")==0)
	{
		strcat(code,"0001"); 
		strcat(code,op1);
		strcat(code,op1);
		strcat(code,"000");
		strcat(code,op1);
		fprintf(fp_w,"%s\n",code); //left shift
		memset(code,0,sizeof(code));//clear code
	}
	else if (strcmp(operation,"ASR")==0)
	{
		
	}
	else if (strcmp(operation,"MOV")==0)
	{
	  if (strlen(op2)>1) //op2 is a register
	  {
		strcat(code,"0101"); 
		strcat(code,op1);
		strcat(code,op1);
		strcat(code,"100000"); 
		fprintf(fp_w,"%s\n",code); //clear op1
		memset(code,0,sizeof(code));//clear code
		
		strcat(code,"0001"); 
		strcat(code,op1);
		strcat(code,op2);
		strcat(code,"100000");	
		fprintf(fp_w,"%s\n",code); //move op2 to op1
		memset(code,0,sizeof(code));//clear code
	  }
	  else //op2 is a hexdecimal
	  {
		  char op2_hex[16]="0";
		  int op2_int;
		  strcat(op2_hex,operand2);
		  op2_int = strtol(op2_hex,NULL,16);
		  itoa(op2_int,op2_hex,2);
		  sprintf(binary_full,"%05s",op2_hex);//add 0 to left
		  strcat(code,"1110"); 
		  strcat(code,op1);
		  strcat(code,binary_full);
		  fprintf(fp_w,"%s\n",code); //move hexdecimal to op1
		memset(code,0,sizeof(code));//clear code
	  }
		
	}
	else if (strcmp(operation,"CMP")==0)
	{
		
	}
	
	/****************************************************************************/
	if (strcmp(operation,"ADD")==0)
	{
		strcat(code,"0001"); 
		strcat(code,op1);
		strcat(code,op2);
		if (strlen(op3)>1) //op3 is a register
		{
			
			strcat(code,"000");
			strcat(code,op3);
			
		}
		else
		{
			if (strstr(operand3,"#")) //operand3 includs "#"
				itoa(atoi(strstr(operand3,"#")+1),binary,2); //convert to binary
			else
				itoa(atoi(operand3),binary,2); //convert to binary
			//printf("binary=%05s",binary);	
			sprintf(binary_full,"%05s",binary);//add 0 to left
			strcat(code,"1");
			strcat(code,binary_full);
			
			
		}
		
			printf("code=%s ",code);
	}
	else if (strcmp(operation,"AND")==0)
	{
		strcat(code,"0101"); 
		strcat(code,op1);
		strcat(code,op2);
		if (strlen(op3)>1) //op3 is a register
		{
			
			strcat(code,"000");
			strcat(code,op3);
			
		}
		else
		{
			if (*operand3=='#')//(strstr(operand3,"#")) //operand3 includs "#"
				itoa(atoi(strstr(operand3,"#")+1),binary,2); //convert to binary
			else
				itoa(atoi(operand3),binary,2); //convert to binary
			//printf("binary=%05s",binary);	
			sprintf(binary_full,"%05s",binary);//add 0 to left
			strcat(code,"1");
			strcat(code,binary_full);
			
			
		}
		
			printf("code=%s\n ",code);
	}
	else if (strcmp(operation,"JMP")==0)
	{
		strcat(code,"1100"); 
		strcat(code,"000");
		strcat(code,op1);
		strcat(code,"000000");
		printf("code=%s ",code);
		//get_code_bin("JMP","R1","R1","0");
	}
	else if (strcmp(operation,"NOT")==0)
	{
		strcat(code,"1001"); 
		strcat(code,op1);
		strcat(code,op2);
		strcat(code,"111111"); 
	}
	else if (strcmp(operation,"LD")==0 || strcmp(operation,"ST")==0 || strcmp(operation,"LDI")==0 || strcmp(operation,"STI")==0)
	{
		if (strcmp(operation,"LD")==0 )
		    strcat(code,"0010"); 
		else if (strcmp(operation,"ST")==0 )
			strcat(code,"0011");
		else if (strcmp(operation,"LDI")==0 )
			strcat(code,"1010");
		else
			strcat(code,"1011");
		strcat(code,op1);
		if (*operand2=='X')
		{
			sscanf(strstr(operand2,"X")+1,"%x",&offset);
			itoa(offset-pc-1,binary,2); //convert to binary
		}
		else
		{
			sysbol_address=read_symbol_table(operand2); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			itoa(offset-pc-1,binary,2);
		}
		sprintf(binary_full,"%09s",binary);//add 0 to left
		strcat(code,binary_full);
	}
	else if (strcmp(operation,"LDR")==0 || strcmp(operation,"STR")==0)
	{
		if (strcmp(operation,"LDR")==0 )
		    strcat(code,"0110"); 
		else
			strcat(code,"0111"); 
		strcat(code,op1);
		if (*operand3=='X')
		{
			sscanf(strstr(operand3,"X")+1,"%x",&offset);
			itoa(offset-pc-1,binary,2); //convert to binary
		}
		else
		{
				sysbol_address=read_symbol_table(operand3); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
				itoa(offset-pc-1,binary,2);
		}
		sprintf(binary_full,"%09s",binary);//add 0 to left
		strcat(code,binary_full);
	}
	else if (strcmp(operation,"LEA")==0)
	{
		strcat(code,"1110"); 
		strcat(code,op1);
		if (*operand2=='#')
		{
			offset=atoi(strstr(operand2,"#")+1); //convert to integer
			itoa(offset,binary,2); //convert to binary
		}
		else
		{
			
			sysbol_address=read_symbol_table(operand2); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			itoa(offset,binary,2);
		}
		sprintf(binary_full,"%09s",binary);//add 0 to left
		strcat(code,binary_full);
	}
	else if (*(operation)=='B' && *(operation+1)=='R')
	{
		strcat(code,"0000"); 
		if(strstr(operation,"N")) //include "N"
			strcat(code,"1"); 
		else 
			strcat(code,"0"); 
		if(strstr(operation,"Z")) //include "Z"
			strcat(code,"1"); 
		else 
			strcat(code,"0");
		if(strstr(operation,"P")) //include "P"
			strcat(code,"1"); 
		else 
			strcat(code,"0");
		if (*operand1=='X')
		{
			sscanf(strstr(operand1,"X")+1,"%x",&offset); //conver to integer
			itoa(offset,binary,2); //convert to binary
		}
		else
		{
			
			sysbol_address=read_symbol_table(operand1); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			itoa(offset-pc-1,binary,2);
		}
		sprintf(binary_full,"%09s",binary);//add 0 to left
		strcat(code,binary_full);
		
	}
	else if (strcmp(operation,"JSR")==0)
	{
		strcat(code,"01001"); 
		if (*operand1=='X')
		{
			sscanf(strstr(operand1,"X")+1,"%x",&offset);
			itoa(offset-pc-1,binary,2); //convert to binary
		}
		else
		{
			sysbol_address=read_symbol_table(operand1); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			itoa(offset-pc-1,binary,2);
		}
		sprintf(binary_full,"%011s",binary);//add 0 to left
		strcat(code,binary_full);
	}
	else if (strcmp(operation,"TRAP")==0)
	{
		strcat(code,"00000000"); 
		
		sscanf(strstr(operand1,"X")+1,"%x",&offset); //start with "X"
			itoa(offset,binary,2); //convert to binary
			sprintf(binary_full,"%08s",binary);//add 0 to left
			strcat(code,binary_full);	
		
		
	}
	else if (strcmp(operation,"RET")==0)
	{
		strcat(code,"1100000111000000"); 		
			
	}
	else if (strcmp(operation,"RTI")==0)
	{
		strcat(code,"1000000000000000"); 		
			
	}
	fprintf(fp_w,"%s\n",code);
}


