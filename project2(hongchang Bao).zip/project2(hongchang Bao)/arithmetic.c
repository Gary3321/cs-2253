#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "get_bin_code.h"

int arithmeti_express(char* exp)
{
	char ops[100], vals[100], pre[100]="0";
	char *ptr,*ops_s, *sysbol_address;
	int oparand,i=0;
	ptr=strtok(exp," ");
	while(ptr != NULL)
	{
		/**convert operand to int **/
		if (*ptr='#') //start with "#"
		{
			ops_s=strstr(exp,"#")+1;
			oparand=atoi(ops_s);
		}
		else if(*ptr='X') //start with "X"
		{
			strcat(pre,ptr);
			oparand = strtol(pre,NULL,16);//convert hex to int
		}
		else 
		{
			sysbol_address=read_symbol_table(ptr); //get address from symbol table
			sscanf(sysbol_address,"%x",&oparand); //conver to decimal
		}
		if(strcmp(ptr,"(")==0){;}
		else if(strcmp(ptr,"+")==0)
		{
			ops[i++]=ptr;
		}
		else if(strcmp(ptr,"-")==0)
		{
			ops[i++]=ptr;
		}
		else if(strcmp(ptr,"*")==0)
		{
			ops[i++]=ptr;
		}
		else if(strcmp(ptr,"/")==0)
		{
			ops[i++]=ptr;
		}
		else if(strcmp(ptr,")")==0)
		{
			char s=ops[--i];
			int v=atoi(vals[--i]);
			if((strcmp(ptr,"+")==0))
			{
				v=atoi(vals[--i]+v);
			}
			else if((strcmp(ptr,"-")==0))
			{
				v=atoi(vals[--i]-v);
			}
			else if((strcmp(ptr,"*")==0))
			{
				v=atoi(vals[--i]*v);
			}
			else if((strcmp(ptr,"/")==0))
			{
				v=atoi(vals[--i]/v);
			}
			vals[i++]=itoa(v);			
		}
		else 
		{
			vals[i++]=ptr;	
		}
		
		ptr=strtok(NULL," ");
	}
	return vals[0];

}
