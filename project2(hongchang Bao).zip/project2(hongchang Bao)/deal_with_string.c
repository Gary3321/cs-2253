#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include<ctype.h>
#include "deal_with_string.h"

char* replacestring(char* src, char* dst)
{
	char* p=dst;
	
	while(*src==' ') //remove first spaces
	{
		src++;
	}
	while(*src) //copy the operation which seperates by space
	{
		*p=*src;
		p++;
		src++;
		if(*src==' ' && *(src+1)!=' ')
		{
			//src++;
			break;
		}
	}
	while(*src)
	{
		
		while(*src==' ' && *(src+1)==' ') //replace many spaces with one space
			src++;
		*p=*src;
		p++;
		src++;		
		if(*src==' ') //replace space with comma
		{
			*p=',';
			p++;
			src++;
		}
		if(*src==';') //don't copy comments
			break;
	}
	*p='\0';
	if(*(p-1)==',')
	{
		*(p-1)=' ';
	}
	return dst;
}

char *upper(char *src)
{
	char *des =src;
	while(*src != '\0')
	{
		if (*src >= 'a' && *src <='z') //convert to upper
			*src -= 'a'-'A';
		src++;
	}
	return des;
}

void trim_string(char *str)  
{  
    char *start, *end;  
    int len = strlen(str);  
  
    
    if(str[len-1] == '\n')  
    {  
        len--;      
        str[len] = 0;   
    }  
  
   
    start = str;        
    end = str + len -1;  
    while(*start && isspace(*start))  
        start++;    
    while(*end && isspace(*end))  
        *end-- = 0;   
    strcpy(str, start);  
}  

char* itoa(int num, char* str, int base)
{

    int i = 0;
    bool isNegative = false;

    if (num == 0)
    {
        str[i++] = '0';
        str[i] = '\0';
        return str;
    }
 
     if (num < 0 && base == 10)
    {
        isNegative = true;
        num = -num;
    }

    while (num != 0)
    {
        int rem = num % base;
        str[i++] = (rem > 9)? (rem-10) + 'a' : rem + '0';
        num = num/base;
    }
 
    if (isNegative)
        str[i++] = '-';
 
    str[i] = '\0'; 
 
        int k;
	int j;
	unsigned char a;
	unsigned len = strlen((const char *)str);
	for (k = 0, j = len - 1; k < j; k++, j--)
	{
		a = str[k];
		str[k] = str[j];
		str[j] = a;
}
 
    return str;
}

