#ifndef _WRITE_SYMBOL_TABLE_H
#define _WRITE_SYMBOL_TABLE_H
bool write_symbol_table(char* filePath)
#endif