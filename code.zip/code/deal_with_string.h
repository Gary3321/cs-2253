#ifndef _DEAL_WITH_STRING_H
#define _DEAL_WITH_STRING_H
char* replacestring(char* src, char* dst);
char *upper(char *src);
void trim_string(char *str);
#endif