#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "deal_with_string.h"
#include "get_bin_code.h"
#include "arithmetic.h"


bool write_symbol_table(char* filePath)
{
	// lines with labels must have them in the first column.
    // lines without labels must have a blank in the first column.
    char data[1000], start_address[100]="0";
	char operations[100]="ADD,AND,BR,JMP,JSR,JSRR,LD,LDI,LDR,LEA,NOT,RET,RTI,ST,STI,STR,TRAP,HALT";
	char *ptr; //store lable
	char *start, *begin; //store start address
	int pc_counter;
    FILE *fp=fopen(filePath,"r");
	FILE *fp_w = fopen("symbol_table.sym","a");
    if(!fp)
    {
        printf("can't open file\n");
        return false;
    }

    while ((fgets(data,1000,fp))!=NULL)
	{
		if(strlen(data)!=1) //don't read empty line,empty line also read "\n". 
		{	printf("%s",data);

			ptr=strtok(data," ");
			trim_string(ptr);//remove space and enter
		if (strstr(operations,ptr)||((*ptr=='B')&&(*(ptr+1)=='R')))
		  {
			  if(strcmp(ptr,"HALT")==0) //pc counter does not increase for "HALT" instruction
				pc_counter--;
		  }
		  else 
		  {
			if(strcmp(ptr,".ORIG")==0)
			{
				start = strtok(NULL," ");

				strcat(start_address,start);
				pc_counter = strtol(start_address,NULL,16);
				pc_counter--; //first instruction is 3000
				printf("pc=%d\n",pc_counter);
				printf("pc=%04x\n",pc_counter+1);
			}

			else
			{
				if(strcmp(ptr,".END")!=0)
				//printf("str2=%s",ptr);
				{			
					
					fprintf(fp_w,"%s",strcat(ptr," "));
					ptr = strtok(NULL," ");
					if (strcmp(ptr,".EQU")==0)
					{
						ptr = strtok(NULL," ");
						fprintf(fp_w,"%s",ptr);
					}
					else
					{
						fprintf(fp_w,"%04x\n",pc_counter);
					}
					
				}
			}
		}
		if(strcmp(ptr,".STRINGZ")==0)
		{
			ptr=strtok(data," ");
			pc_counter=pc_counter+strlen(ptr)-2+1; //account for surrounding quotes
		}
		else 
			pc_counter++;
		}
	}
	fclose(fp_w);
    fclose(fp);
    return true;
}

bool ReadFile(char* filePath)
{
	// lines with labels must have them in the first column.
    // lines without labels must have a blank in the first column.
    char data[1000],line[1000],line_bk[1000], start_address[100]="0";
	char operations[100]="ADD,AND,BR,JMP,JSR,JSRR,LD,LDI,LDR,LEA,NOT,RET,RTI,ST,STI,STR,TRAP,HALT";
	char *ptr; //store lable
	
	char *operand1, *operand2, *operand3;
	char *start, *begin; //store start address
	int pc_counter;
    FILE *fp=fopen(filePath,"r");
	FILE *fp_w = fopen("out.bin","a");
    if(!fp)
    {
        printf("can't open file\n");
        return false;
    }
	if(!fp_w)
    {
        printf("can't open file\n");
        return false;
    }
	operand1=operand2=operand3="";
    while ((fgets(data,1000,fp))!=NULL)
	{
		operand1=operand2=operand3="";
		if(strlen(data)!=1) //don't read empty line,empty line also read "\n". 
		{	printf("%s\n",data);
		
		//if (data[0]!=' ')
       // {
			//printf("str2=%c",data[0]);
			replacestring(data,line);
			trim_string(line);//remove space and enter
			upper(line);
			ptr=strtok(line," ");			
			//trim_string(ptr);
			printf("/n*ptr=%c,ptr+1=%c/n",*ptr,*(ptr+1));
		if (strstr(operations,ptr)||((*ptr=='B')&&(*(ptr+1)=='R')))
		  {
			  if(strcmp(ptr,"HALT")==0) //pc counter does not increase for "HALT" instruction
				pc_counter--;
			if(((*ptr=='B')&&(*(ptr+1)=='R'))||((*ptr=='J')&&(*(ptr+1)=='S')))
			{
				operand1=strtok(NULL," ");
			}
			else
			{
				
			  operand1=strtok(NULL,",");
			  operand2=strtok(NULL,",");
			  operand3=strtok(NULL,",");
			}
			  if (operand1=='\0')
				operand1="";
			  if (operand2=='\0')
				operand2="";
			  if (operand3=='\0')
				operand3="";
			 
			  //trim_string(operand2);
			  printf("p=%s,o1=%s,o2=%s,o3=%s,pc=%d",ptr, operand1, operand2, operand3,pc_counter);
			  get_code_bin(ptr, operand1, operand2, operand3, fp_w, pc_counter);
		  }
		  else 
		  {
			if(strcmp(ptr,".ORIG")==0)
			{
				start = strtok(NULL," ");
				strcat(start_address,start);
				pc_counter = strtol(start_address,NULL,16);
				itoa(pc_counter,start,2);
				pc_counter--; //first instruction is 3000
				fprintf(fp_w,"%s\n",start);
				
			}
			
		}
		if(strcmp(ptr,".STRINGZ")==0)
		{
			ptr=strtok(data," ");
			pc_counter=pc_counter+strlen(ptr)-2+1; //account for surrounding quotes
		}
		else 
			pc_counter++;
		}
	}
	fclose(fp_w);
    fclose(fp);
    return true;
}

int main()
{
	write_symbol_table("1.asm");
    ReadFile("1.asm");
	system("lc3convert out.bin");
    return 0;
}
