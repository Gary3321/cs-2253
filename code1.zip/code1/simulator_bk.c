#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "deal_with_string.h"
#include "get_bin_code.h"
//#include "write_symbol_table.h"


void trim_string(char *str) ;
void get_code_bin(char* operation, char* operand1, char* operand2, char* operand3, FILE *fp_w, int pc);
char* read_symbol_table(char* symbol);
char* get_operand_bin(char *operand);
char* replacestring(char* src, char* dst);
char *upper(char *src);

bool write_symbol_table(char* filePath)
{
	// lines with labels must have them in the first column.
    // lines without labels must have a blank in the first column.
    char data[1000], start_address[100]="0";
	char operations[100]="ADD,AND,BR,JMP,JSR,JSRR,LD,LDI,LDR,LEA,NOT,RET,RTI,ST,STI,STR,TRAP,HALT";
	char *ptr; //store lable
	char *start, *begin; //store start address
	int pc_counter;
    FILE *fp=fopen(filePath,"r");
	FILE *fp_w = fopen("symbol_table.sym","a");
    if(!fp)
    {
        printf("can't open file\n");
        return false;
    }

    while ((fgets(data,1000,fp))!=NULL)
	{
		if(strlen(data)!=1) //don't read empty line,empty line also read "\n". 
		{	printf("%s",data);
		
		//if (data[0]!=' ')
       // {
			//printf("str2=%c",data[0]);
			ptr=strtok(data," ");
			trim_string(ptr);//remove space and enter
		if (strstr(operations,ptr)||((*ptr=='B')&&(*(ptr+1)=='R')))
		  {
			  if(strcmp(ptr,"HALT")==0) //pc counter does not increase for "HALT" instruction
				pc_counter--;
		  }
		  else 
		  {
			if(strcmp(ptr,".ORIG")==0)
			{
				start = strtok(NULL," ");
				//begin=strstr(start,"X")+1;
				//printf("start=%s,begin=%s,first=%c",strcat(start_address,start),begin,*start);
				strcat(start_address,start);
				pc_counter = strtol(start_address,NULL,16);
				pc_counter--; //first instruction is 3000
				printf("pc=%d\n",pc_counter);
				printf("pc=%04x\n",pc_counter+1);
			}
			//if(*(start)=='X')
			//printf("str2=%s%s\n",ptr,  start  );
			//printf("begin=%s\n",strcpy("0",start)  );
			else
			{
				if(strcmp(ptr,".END")!=0)
				//printf("str2=%s",ptr);
				{					
					fprintf(fp_w,"%s",strcat(ptr," "));
					fprintf(fp_w,"%04x\n",pc_counter);
				}
			}
		}
		if(strcmp(ptr,".STRINGZ")==0)
		{
			ptr=strtok(data," ");
			pc_counter=pc_counter+strlen(ptr)-2+1; //account for surrounding quotes
		}
		else 
			pc_counter++;
		}
	}
	fclose(fp_w);
    fclose(fp);
    return true;
}

bool ReadFile(char* filePath)
{
	// lines with labels must have them in the first column.
    // lines without labels must have a blank in the first column.
    char data[1000],line[1000],line_bk[1000], start_address[100]="0";
	char operations[100]="ADD,AND,BR,JMP,JSR,JSRR,LD,LDI,LDR,LEA,NOT,RET,RTI,ST,STI,STR,TRAP,HALT";
	char *ptr; //store lable
	
	char *operand1, *operand2, *operand3;
	char *start, *begin; //store start address
	int pc_counter;
    FILE *fp=fopen(filePath,"r");
	FILE *fp_w = fopen("bin.sym","a");
    if(!fp)
    {
        printf("can't open file\n");
        return false;
    }
	if(!fp_w)
    {
        printf("can't open file\n");
        return false;
    }
	operand1=operand2=operand3="";
    while ((fgets(data,1000,fp))!=NULL)
	{
		operand1=operand2=operand3="";
		if(strlen(data)!=1) //don't read empty line,empty line also read "\n". 
		{	printf("%s\n",data);
		
		//if (data[0]!=' ')
       // {
			//printf("str2=%c",data[0]);
			replacestring(data,line);
			trim_string(line);//remove space and enter
			upper(line);
			ptr=strtok(line," ");			
			//trim_string(ptr);
			printf("/n*ptr=%c,ptr+1=%c/n",*ptr,*(ptr+1));
		if (strstr(operations,ptr)||((*ptr=='B')&&(*(ptr+1)=='R')))
		  {
			  if(strcmp(ptr,"HALT")==0) //pc counter does not increase for "HALT" instruction
				pc_counter--;
			if(((*ptr=='B')&&(*(ptr+1)=='R'))||((*ptr=='J')&&(*(ptr+1)=='S')))
			{
				operand1=strtok(NULL," ");
			}
			else
			{
				
			  operand1=strtok(NULL,",");
			  operand2=strtok(NULL,",");
			  operand3=strtok(NULL,",");
			}
			  if (operand1=='\0')
				operand1="";
			  if (operand2=='\0')
				operand2="";
			  if (operand3=='\0')
				operand3="";
			 
			  //trim_string(operand2);
			  printf("p=%s,o1=%s,o2=%s,o3=%s,pc=%d",ptr, operand1, operand2, operand3,pc_counter);
			  get_code_bin(ptr, operand1, operand2, operand3, fp_w, pc_counter);
		  }
		  else 
		  {
			if(strcmp(ptr,".ORIG")==0)
			{
				start = strtok(NULL," ");
				//begin=strstr(start,"X")+1;
				//printf("start=%s,begin=%s,first=%c",strcat(start_address,start),begin,*start);
				strcat(start_address,start);
				pc_counter = strtol(start_address,NULL,16);
				itoa(pc_counter,start,2);
				pc_counter--; //first instruction is 3000
				fprintf(fp_w,"%s\n",start);
				//printf("pc=%s\n",start);
				//printf("pc=%04x\n",pc_counter+1);
			}
			//if(*(start)=='X')
			//printf("str2=%s%s\n",ptr,  start  );
			//printf("begin=%s\n",strcpy("0",start)  );
			/*else
			{
				if(strcmp(ptr,".END")!=0)
				//printf("str2=%s",ptr);
				{					
					fprintf(fp_w,"%s",strcat(ptr," "));
					fprintf(fp_w,"%04x\n",pc_counter);
				}
			}*/
		}
		if(strcmp(ptr,".STRINGZ")==0)
		{
			ptr=strtok(data," ");
			pc_counter=pc_counter+strlen(ptr)-2+1; //account for surrounding quotes
		}
		else 
			pc_counter++;
		}
	}
	fclose(fp_w);
    fclose(fp);
    return true;
}

int main()
{
	write_symbol_table("1.asm");
    ReadFile("1.asm");
    return 0;
}

void trim_string(char *str)  
{  
    char *start, *end;  
    int len = strlen(str);  
  
    //remove enter
    if(str[len-1] == '\n')  
    {  
        len--;      
        str[len] = 0; 
    }  
  
   //remove spaces
    start = str;        
    end = str + len -1;  
    while(*start && isspace(*start))  
        start++;    
    while(*end && isspace(*end))  
        *end-- = 0; 
    strcpy(str, start); 
}  
char* get_operand_bin(char *operand)
{
	if (strstr(operand,"R"))	
	{
		if (strcmp(operand, "R0")==0) return "000";
		if (strcmp(operand, "R1")==0) return "001";
		if (strcmp(operand, "R2")==0) return "010";
		if (strcmp(operand, "R3")==0) return "011";
		if (strcmp(operand, "R4")==0) return "100";
		if (strcmp(operand, "R5")==0) return "101";
		if (strcmp(operand, "R6")==0) return "110";
		if (strcmp(operand, "R7")==0) return "111";
		else return ""; //return null
	}
		else return ""; 
}
char* read_symbol_table(char* symbol)
{
	FILE *fp=fopen("symbol_table.sym","r");
	char data[1000];
	char* ptr;
	if(!fp)
    {
        printf("can't open file\n");
        return false;
    }
	while ((fgets(data,1000,fp))!=NULL)
	{
	if(strlen(data)!=1) 
	{
		ptr=strtok(data," ");
		trim_string(ptr);//remove space and enter
		if(strcmp(ptr,symbol)==0)
		{
			ptr = strtok(NULL," ");
			trim_string(ptr);
			return ptr;
		}
	}
	}
	fclose(fp);
	return "3fff";//error
}
void get_code_bin(char* operation, char* operand1, char* operand2, char* operand3, FILE *fp_w, int pc)
{
	char* op3=get_operand_bin(operand3);
	char* op2=get_operand_bin(operand2);
	char* op1=get_operand_bin(operand1);
	char* sysbol_address;
	char code[16]; //bin code
	char binary[16]; //binary
	char binary_full[16]; //binary with length of 5
	int op3_int,offset;
	//char *code_bin;
	if (strcmp(operation,"ADD")==0)
	{
		strcat(code,"0001"); 
		strcat(code,op1);
		strcat(code,op2);
		if (strlen(op3)>1) //op3 is a register
		{
			
			strcat(code,"000");
			strcat(code,op3);
			
		}
		else
		{
			if (strstr(operand3,"#")) //operand3 includs "#"
				itoa(atoi(strstr(operand3,"#")+1),binary,2); //convert to binary
			else
				itoa(atoi(operand3),binary,2); //convert to binary
			//printf("binary=%05s",binary);	
			sprintf(binary_full,"%05s",binary);//add 0 to left
			strcat(code,"1");
			strcat(code,binary_full);
			
			
		}
		
			printf("code=%s ",code);
	}
	else if (strcmp(operation,"AND")==0)
	{
		strcat(code,"0101"); 
		strcat(code,op1);
		strcat(code,op2);
		if (strlen(op3)>1) //op3 is a register
		{
			
			strcat(code,"000");
			strcat(code,op3);
			
		}
		else
		{
			if (*operand3=='#')//(strstr(operand3,"#")) //operand3 includs "#"
				itoa(atoi(strstr(operand3,"#")+1),binary,2); //convert to binary
			else
				itoa(atoi(operand3),binary,2); //convert to binary
			//printf("binary=%05s",binary);	
			sprintf(binary_full,"%05s",binary);//add 0 to left
			strcat(code,"1");
			strcat(code,binary_full);
			
			
		}
		
			printf("code=%s\n ",code);
	}
	else if (strcmp(operation,"JMP")==0)
	{
		strcat(code,"1100"); 
		strcat(code,"000");
		strcat(code,op1);
		strcat(code,"000000");
		printf("code=%s ",code);
		//get_code_bin("JMP","R1","R1","0");
	}
	else if (strcmp(operation,"NOT")==0)
	{
		strcat(code,"1001"); 
		strcat(code,op1);
		strcat(code,op2);
		strcat(code,"111111"); 
	}
	else if (strcmp(operation,"LD")==0 || strcmp(operation,"ST")==0 || strcmp(operation,"LDI")==0 || strcmp(operation,"STI")==0)
	{
		if (strcmp(operation,"LD")==0 )
		    strcat(code,"0010"); 
		else if (strcmp(operation,"ST")==0 )
			strcat(code,"0011");
		else if (strcmp(operation,"LDI")==0 )
			strcat(code,"1010");
		else
			strcat(code,"1011");
		strcat(code,op1);
		if (*operand2=='X')
		{
			sscanf(strstr(operand2,"X")+1,"%x",&offset);
			itoa(offset-pc-1,binary,2); //convert to binary
		}
		else
		{
			//	itoa(atoi(operand3),binary,2); //convert to binary
			sysbol_address=read_symbol_table(operand2); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			//printf("sysbol_address=%s,offset=%d,pc=%d",sysbol_address,offset,pc);
			itoa(offset-pc-1,binary,2);
		}
		sprintf(binary_full,"%09s",binary);//add 0 to left
		//printf("binary=%s",binary_full);
		strcat(code,binary_full);
	}
	else if (strcmp(operation,"LDR")==0 || strcmp(operation,"STR")==0)
	{
		if (strcmp(operation,"LDR")==0 )
		    strcat(code,"0110"); 
		else
			strcat(code,"0111"); 
		strcat(code,op1);
		if (*operand3=='X')
		{
			sscanf(strstr(operand3,"X")+1,"%x",&offset);
			itoa(offset-pc-1,binary,2); //convert to binary
		}
		else
		{
			//	itoa(atoi(operand3),binary,2); //convert to binary
			sysbol_address=read_symbol_table(operand3); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			//printf("sysbol_address=%s,offset=%d,pc=%d",sysbol_address,offset,pc);
			itoa(offset-pc-1,binary,2);
		}
		sprintf(binary_full,"%09s",binary);//add 0 to left
		//printf("binary=%s",binary_full);
		strcat(code,binary_full);
	}
	else if (strcmp(operation,"LEA")==0)
	{
		strcat(code,"1110"); 
		strcat(code,op1);
		if (*operand2=='#')
		{
			offset=atoi(strstr(operand2,"#")+1); //convert to integer
			itoa(offset,binary,2); //convert to binary
		}
		else
		{
			//	itoa(atoi(operand3),binary,2); //convert to binary
			sysbol_address=read_symbol_table(operand2); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			//printf("sysbol_address=%s,offset=%d,pc=%d",sysbol_address,offset,pc);
			itoa(offset,binary,2);
		}
		sprintf(binary_full,"%09s",binary);//add 0 to left
		//printf("binary=%s",binary_full);
		strcat(code,binary_full);
	}
	else if (*(operation)=='B' && *(operation+1)=='R')
	{
		strcat(code,"0000"); 
		if(strstr(operation,"N")) //include "N"
			strcat(code,"1"); 
		else 
			strcat(code,"0"); 
		if(strstr(operation,"Z")) //include "Z"
			strcat(code,"1"); 
		else 
			strcat(code,"0");
		if(strstr(operation,"P")) //include "P"
			strcat(code,"1"); 
		else 
			strcat(code,"0");
		if (*operand1=='X')
		{
			sscanf(strstr(operand1,"X")+1,"%x",&offset); //conver to integer
			itoa(offset,binary,2); //convert to binary
		}
		else
		{
			//	itoa(atoi(operand3),binary,2); //convert to binary
			sysbol_address=read_symbol_table(operand1); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			//printf("sysbol_address=%s,offset=%d,pc=%d",sysbol_address,offset,pc);
			itoa(offset-pc-1,binary,2);
		}
		sprintf(binary_full,"%09s",binary);//add 0 to left
		//printf("binary=%s",binary_full);
		strcat(code,binary_full);
		
	}
	else if (strcmp(operation,"JSR")==0)
	{
		strcat(code,"01001"); 
		if (*operand1=='X')
		{
			sscanf(strstr(operand1,"X")+1,"%x",&offset);
			itoa(offset-pc-1,binary,2); //convert to binary
		}
		else
		{
			//	itoa(atoi(operand3),binary,2); //convert to binary
			sysbol_address=read_symbol_table(operand1); //get address from symbol table
			sscanf(sysbol_address,"%x",&offset); //conver to decimal
			//printf("sysbol_address=%s,offset=%d,pc=%d",sysbol_address,offset,pc);
			itoa(offset-pc-1,binary,2);
		}
		sprintf(binary_full,"%011s",binary);//add 0 to left
		//printf("binary=%s",binary_full);
		strcat(code,binary_full);
	}
	else if (strcmp(operation,"TRAP")==0)
	{
		strcat(code,"00000000"); 
		
		sscanf(strstr(operand1,"X")+1,"%x",&offset); //start with "X"
			itoa(offset,binary,2); //convert to binary
			sprintf(binary_full,"%08s",binary);//add 0 to left
			//printf("binary=%s",binary_full);
			strcat(code,binary_full);
		
		
		
	}
	else if (strcmp(operation,"RET")==0)
	{
		strcat(code,"1100000111000000"); 		
			
	}
	else if (strcmp(operation,"RTI")==0)
	{
		strcat(code,"1000000000000000"); 		
			
	}
	fprintf(fp_w,"%s\n",code);
}
char* replacestring(char* src, char* dst)
{
	char* p=dst;
	
	while(*src==' ') //remove first spaces
	{
		src++;
	}
	while(*src) //copy the operation which seperates by space
	{
		*p=*src;
		p++;
		src++;
		if(*src==' ' && *(src+1)!=' ')
		{
			//src++;
			break;
		}
	}
	while(*src)
	{
		
		while(*src==' ' && *(src+1)==' ') //replace many spaces with one space
			src++;
		*p=*src;
		p++;
		src++;		
		if(*src==' ') //replace space with comma
		{
			*p=',';
			p++;
			src++;
		}
		if(*src==';') //don't copy comments
			break;
	}
	*p='\0';
	if(*(p-1)==',')
	{
		*(p-1)=' ';
		//*(++p)='\0';
	}
	return dst;
}

char *upper(char *src)
{
	char *des =src;
	while(*src != '\0')
	{
		if (*src >= 'a' && *src <='z') //convert to upper
			*src -= 'a'-'A';
		src++;
	}
	return des;
}
