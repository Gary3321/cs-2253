#ifndef _ARITHMETIC_H
#define _ARITHMETIC_H
int arithmeti_express(char* exp);
#endif