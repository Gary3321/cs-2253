#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "deal_with_string.h"


//void trim_string(char *str) ;
bool write_symbol_table(char* filePath)
{
	// lines with labels must have them in the first column.
    // lines without labels must have a blank in the first column.
    char data[1000], start_address[100]="0";
	char operations[100]="ADD,AND,BR,JMP,JSR,JSRR,LD,LDI,LDR,LEA,NOT,RET,RTI,ST,STI,STR,TRAP,HALT";
	char *ptr; //store lable
	char *start, *begin; //store start address
	int pc_counter;
    FILE *fp=fopen(filePath,"r");
	FILE *fp_w = fopen("symbol_table.sym","a");
    if(!fp)
    {
        printf("can't open file\n");
        return false;
    }

    while ((fgets(data,1000,fp))!=NULL)
	{
		if(strlen(data)!=1) //don't read empty line,empty line also read "\n". 
		{	printf("%s",data);
		
		//if (data[0]!=' ')
       // {
			//printf("str2=%c",data[0]);
			ptr=strtok(data," ");
			trim_string(ptr);//remove space and enter
		if (strstr(operations,ptr)||((*ptr=='B')&&(*(ptr+1)=='R')))
		  {
			  if(strcmp(ptr,"HALT")==0) //pc counter does not increase for "HALT" instruction
				pc_counter--;
		  }
		  else 
		  {
			if(strcmp(ptr,".ORIG")==0)
			{
				start = strtok(NULL," ");
				//begin=strstr(start,"X")+1;
				//printf("start=%s,begin=%s,first=%c",strcat(start_address,start),begin,*start);
				strcat(start_address,start);
				pc_counter = strtol(start_address,NULL,16);
				pc_counter--; //first instruction is 3000
				printf("pc=%d\n",pc_counter);
				printf("pc=%04x\n",pc_counter+1);
			}
			//if(*(start)=='X')
			//printf("str2=%s%s\n",ptr,  start  );
			//printf("begin=%s\n",strcpy("0",start)  );
			else
			{
				if(strcmp(ptr,".END")!=0)
				//printf("str2=%s",ptr);
				{					
					fprintf(fp_w,"%s",strcat(ptr," "));
					fprintf(fp_w,"%04x\n",pc_counter);
				}
			}
		}
		if(strcmp(ptr,".STRINGZ")==0)
		{
			ptr=strtok(data," ");
			pc_counter=pc_counter+strlen(ptr)-2+1; //account for surrounding quotes
		}
		else 
			pc_counter++;
		}
	}
	fclose(fp_w);
    fclose(fp);
    return true;
}

/*
int main()
{
    ReadFile("1.asm");
    return 0;
}

void trim_string(char *str)  
{  
    char *start, *end;  
    int len = strlen(str);  
  
    //ȥ�����Ļ��з�  
    if(str[len-1] == '\n')  
    {  
        len--;      //�ַ������ȼ�һ  
        str[len] = 0;   //���ַ������һ���ַ���0����������  
    }  
  
    //ȥ�����˵Ŀո�  
    start = str;        //ָ�����ַ�  
    end = str + len -1; //ָ�����һ���ַ�  
    while(*start && isspace(*start))  
        start++;    //����ǿո��׵�ַ��ǰ��һλ��������ǣ���������ѭ��  
    while(*end && isspace(*end))  
        *end-- = 0; //����ǿո�ĩ��ַ��ǰ��һλ������������  
    strcpy(str, start); //���׵�ַ����str  
}  
*/
